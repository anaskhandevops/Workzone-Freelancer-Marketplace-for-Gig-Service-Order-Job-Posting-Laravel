<?php
 return array (
  'Sub Category List' => 'Sub Category List',
  'Sub Category' => 'Sub Category',
  'Create Sub Category' => 'Create Sub Category',
  'Select Subcategory' => 'Select Sub Category',
  'Subcategory' => 'Sub Category',
  'All Categories' => 'All Categories',
  'Sub Categories' => 'Sub Categories',
  'Sub Category is required' => 'Sub Category is required',
);
 ?>
