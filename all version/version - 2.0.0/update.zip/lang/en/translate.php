<?php
 return array (

  'Buyer || Wallet' => 'Buyer || Wallet',
  'Wallet' => 'Wallet',
  'Add Balance' => 'Add Balance',
  'Buyer || Add Balance' => 'Buyer || Add Balance',
  'Pay Now' => 'Pay Now',
  'Amount is required' => 'Amount is required',
  'You have to add minimum 10 USD' => 'You have to add minimum 10 USD',
  'Please provide numeric value' => 'Please provide numeric value',
  'Payment gateway is required' => 'Payment gateway is required',
  'The payment has been added to your wallet' => 'The payment has been added to your wallet',
  'Stripe Payment' => 'Stripe Payment',
  'Mollie' => 'Mollie',
  'Do not have enough balance to your wallet' => 'Do not have enough balance to your wallet',
  'Used Balance' => 'Used Balance',
  'Total Balance' => 'Total Balance',
  'Wallet Transaction' => 'Wallet Transaction',
  'Gateway' => 'Gateway',
  'Razorpay' => 'Razorpay',
  'Please wait. Your payment is processing....' => 'Please wait. Your payment is processing....',
  'Do not press browser back or forward button while you are in payment page' => 'Do not press browser back or forward button while you are in payment page',

  'Live Chat' => 'Live Chat',
  'Buyer || Live Chat' => 'Buyer || Live Chat',
  'Seller List' => 'Seller List',
  'Type your message' => 'Type your message',
  'Buyer List' => 'Buyer List',
  'Send Message' => 'Send Message',
  'Please login as a buyer' => 'Please login as a buyer',
  'No Message Yet' => 'No Message Yet',
  'Please choose one' => 'Please choose one',

);
 ?>
